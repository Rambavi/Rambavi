var request = require('request');
var Buffer = require('buffer').Buffer;
var LZUTF8 = require('lzutf8');
var unirest = require('unirest');
var recent_all = [];
var r_ids_new=[];
var c_Ticket_id = [];
var groupserver;

exports = {

  events: [
    { event: "onAppInstall", callback: "onAppInstallHandler" },
    { event: "onAppUninstall", callback: "onAppUninstallCallback" },
    { event: "onScheduledEvent", callback: "onScheduledEventHandler" },
    { event: 'onConversationCreate', callback: 'onConversationCreateHandler' }
  ],
  onAppInstallHandler: function(args) {
    getCustomFields(args);
    renderData();
  },
  onAppUninstallCallback: function (args) {
    console.log("/////////////scheduleDelete///////////////////");
	  console.log(args);
	  $schedule
		.delete({
		  name: "schedule_fetchdata",
		})
		.then(
		  function (data) {
			console.log("Delete schedule after then fun...  ");
			renderData(null, data);
		  },
		  function (err) {
			renderData(err);
		  }
		);
 },
 onScheduledEventHandler: async function (args) {
  try {
        r_ids_new=[];
       var date = new Date();
      console.log("Scheduler Starts", date);
   //Agent API
   let agent_name =args['iparams'].agent_id?args['iparams'].agent_id:await fetch_agent_api(args);
   let recent_all2=[];
   //Calculation		
   let iparams_mins=(args['iparams'].cond=="Days")?(args['iparams'].no_of_hours*24)*60:args['iparams'].no_of_hours;  
      console.log(iparams_mins);
   if((args['iparams'].cond == "Days") ){
      // var hours = date.getMinutes() - iparams_mins;
      // date.setMinutes(hours);
     var last_active = date;
     var startdate = last_active;
     var startdate = last_active.toJSON();      
     var searchdate = startdate.slice(0, 4) + '-' + startdate.slice(5, 7) + '-' + startdate.slice(8, 10);
     console.log(searchdate);
     //Tickets API 
     recent_all2 = await filterTickets(args,searchdate, 1);
     recent_all2 = recent_all2.filter(function(e) {
      return (e.association_type != 2 && e.association_type != 1 && e.status != 4 && e.status != 5);
      }); 
   }
   else{
     //Tickets API
      recent_all2 = await recentTicketsNew12(args,1);
      recent_all2 = recent_all2.filter(function(e) {
        return (e.association_type != 2 && e.association_type != 1 && e.status != 4 && e.status != 5);
        }); 
   }
  //  console.log("recent_all",recent_all2.map(e=> e.id),recent_all2.length);  		
   recent_all=recent_all2.sort((a,b) => (a.id > b.id) ? 1 : ((b.id > a.id) ? -1 : 0));
   console.log("recent_all After sort",recent_all.map(e=> e.id),recent_all.length); 
    
   let bb=[];let match_id=recent_all;
   groupserver = args['iparams'].pages;
if(groupserver == null){
  // if(groupserver == ""){
    for(let i = 0; i < recent_all.length; i++) { 
     bb=[];	console.log("iiiiiiiiiiii",i);
    for(let k = i + 1; k < recent_all.length; k++) {
      // console.log("kkkkkkk...",k);
      if((recent_all[i].requester_id == recent_all[k].requester_id) &&(recent_all[k].custom_fields.cf_primary_ticket_id == null)){				 				
      //Time Calculation
          date1=new Date(recent_all[i].created_at);
          date2=new Date(recent_all[k].created_at);
          const diffTime = Math.abs(date2 - date1);
          const diffMins =  diffTime/60000;  
          
          let iparams_mins=(args['iparams'].cond=="Days")?(args['iparams'].no_of_hours*24)*60:args['iparams'].no_of_hours;

          if(diffMins<=iparams_mins){	
          bb.push(recent_all[k]);
          }
          else{
            console.log("else break ...recent_all[i].id,recent_all[k].id",recent_all[i].id,recent_all[k].id,diffMins,recent_all[i].created_at,recent_all[k].created_at,"Status",recent_all[k].status,recent_all[k].custom_fields.cf_primary_ticket_id);
            break;
          }
       }
     }//console.log("End of k loop",recent_all.map(e=> e.id));
           
      if(bb.length>0){
    //step 1
    
     bb.push(recent_all[i]);bb.sort((a,b) => (a.id > b.id) ? 1 : ((b.id > a.id) ? -1 : 0));
    // console.log("bb*******",bb);

     var existIds = bb[0].custom_fields.cf_child_ticket_id;
     let arrNew = JSON.parse("[" + existIds + "]");	
      var parentid = bb[0].id;  console.log("parentid", bb[0].id);
    // console.log("..............bb",bb.map(e=> e.id));//1,3,7,9  //promise All
         
    for(var tt=1;tt<bb.length;tt++){	
             arrNew.push(bb[tt].id);
            var arr =  arrNew.filter(item => item != null);
            await close_child(args, parentid, bb[tt], agent_name);
            await childNoteAdd(args,parentid, bb[tt]);
         }  
		  console.log("existIds*******",arr);

	       await update_child1(args, parentid,arr);
   
    //step 2
     recent_all = recent_all.filter(el => {
            return !bb.find(element => {
               return element.id === el.id;
            });
         });		
      console.log("..............rrrrrrrr ",recent_all.map(e=> e.id));
      i=0;
     }
      }
     }
else{
  let i=0;
  while(i < recent_all.length){
  bb=[];
    // console.log("iiiiiiiiiiii",i);
     console.log("groupserver == ",groupserver);
     for(var a = 0; a < groupserver.length; a++) {
                       var findRoleCan3 = groupserver.filter(e=> e.id == a+1);	
                   if(findRoleCan3.length != 0 ){
                    var cus =  findRoleCan3[0].page_id;
                      let bool=groupserver.findIndex(f=> f.fd_status ==  recent_all[i].custom_fields[cus]);
                     console.log("groupserver == ", bool);
                      if(bool!=-1){
                         match_id = match_id.filter(e => {
                           return (((e.requester_id == recent_all[i].requester_id)) && (e.custom_fields[cus] == recent_all[i].custom_fields[cus]));
                         });
                       } else{
                         match_id=[];
                       }
                      }
                    }
   console.log("After filter matches...match_id",match_id.map(e=> e.id));
  i++;
   if(match_id.length>0){
    var existIds = match_id[0].custom_fields.cf_child_ticket_id;
    let arrNew = JSON.parse("[" + existIds + "]");	
    console.log("existIds*******",existIds);
    for(var j=0;j<match_id.length;j++){
      bb=[];
      // console.log("jjjjjjjj",j,match_id.length);//1
      for(var t = j + 1; t < match_id.length; t++){
        // console.log("match_id[j],[t]...",match_id[j].id,match_id[t].id);
            //Time Calculation
          date1=new Date(match_id[j].created_at);
          date2=new Date(match_id[t].created_at);
          const diffTime = Math.abs(date2 - date1);
          const diffMins =  diffTime/60000;  
          
          let iparams_mins=(args['iparams'].cond=="Days")?(args['iparams'].no_of_hours*24)*60:args['iparams'].no_of_hours;
        if(diffMins<=iparams_mins){	
          arrNew.push(match_id[t].id);
         var arr =  arrNew.filter(item => item != null);
		  console.log("existIds*******",arr);
		       await update_child1(args, match_id[j].id,arr);
          await close_child(args, match_id[j].id, match_id[t], agent_name);
          await childNoteAdd(args,match_id[j].id, match_id[t]);
          bb.push(match_id[t]);
          } 
          else{console.log("else",diffMins);							 
            break;
          }
      }
      if(bb && bb.length>0){//1,2
        //step 1
         recent_all = recent_all.filter(el => {
                return !bb.find(element => {
                   return element.id === el.id;
                });
             });		
          console.log("..............rrrrrrrr ",recent_all.map(e=> e.id));
          i=0;
       }
       break;//for j loop
       }
  }				 
   console.log("Check Time Ends");
   match_id=recent_all;
  }
}
} catch (error) {
     console.log("Error", error);
   }  
 },
  // args is a JSON block containing the payload information.
  // args['iparam'] will contain the installation parameter values.
  onConversationCreateHandler: async function (args) {
	
    try {
       var c_id = args['data']['conversation']['ticket_id'];
       console.log("c_id", c_id);
       var conversationcontent = await fetchData(args, c_id);
       if (conversationcontent.custom_fields.cf_primary_ticket_id == null && conversationcontent.status == 5) {
        
         console.log("conversation Terminates");
       }
       else {
         var parent_id = conversationcontent.custom_fields.cf_primary_ticket_id;
         console.log("parent id---", parent_id);
        
         var conv = await fetch_conversation(args, c_id);
         //  console.log(conv);
          let len = conv.length - 1;
         var description = conversationcontent.description;
         // console.log(description);
         var attachments = conv[len].body;
           await add_conversation(args, parent_id, description, attachments);

  if(parent_id !=null){

    await  getParentticket(args, parent_id);	}

  //    $db.get(`${parent_id}`).then (function(data) {
  //              var child_id = data.childId;
  //         // var c_arr = child_id.split(",");
  //         c_Ticket_id = c_Ticket_id.concat(child_id,conversationcontent.id);
  //         console.log("c_Ticket_id...",c_Ticket_id);
          
  //       $db.set(`${parent_id}`, { "childId":  c_Ticket_id}).then ( function(data) {
  //          console.log(data);
  //         update_child1(args, parent_id,c_Ticket_id);
  //       },
  //       function(error) {
  //         // failure operation
  //         console.log(error);
  //       });
  //       // }
       
  //     },
  //     function(error) {
  //           console.log(error);
  //              c_Ticket_id.push(conversationcontent.id);
  //           $db.set(`${parent_id}`, { "childId":  c_Ticket_id}).then (
  //             function(data) {
  //               console.log(data);
  //               update_child1(args, parent_id,c_Ticket_id);
  //             },
  //             function(error) {
  //               // failure operation
  //               console.log(error);
  //             }); 
  //     });
  //  }else{
  //         $db.delete(`${parent_id}`).then (
  //           function(data) {
  //             // success operation
  //             console.log("Deleted",data);
  //             // "data" value is {  : true }
  //           },
  //           function(error) {
  //             console.log(error)
  //             // failure operation
  //           });
  //       }
 
       }
     } catch (error) {
       console.log(error);
     }
   }
// serverMethod:  function(options) {
//   // app logic resides here
 
//   getIterationForProject();
// }
};

function getCustomFields(args){
  var headers = {
    'Authorization': getToken(args),
   'Content-Type': 'application/json' 
};
var options = { 
   method:"GET",
   url:`${getDomain(args)}/api/v2/ticket_fields`,
  headers: headers
 
};
request(options,(error, res, body) => {

  if(body)
   {        
    var ticket_fields = JSON.parse(body);
     var texts =[];
   for (let ii = 0; ii < ticket_fields.length; ii++) {
    texts.push(ticket_fields[ii].label);
  }
   let textname=texts.findIndex(f=> f == 'Primary Ticket ID');
   let textname1=texts.findIndex(f=> f == 'Child Ticket ID' );
     if(textname==-1 && textname1 == -1){
      createcustomFields(args);
      createcustomFields_1(args);
     }else if(textname1 == -1){
      createcustomFields_1(args);
       }else if(textname == -1){
        createcustomFields(args);
       }
     ticket_fields = ticket_fields.filter(e => e.name == "status");
         var status = ticket_fields[0].choices;
         var sts = Object.keys(status);
      sts = sts.filter(val => val !== "4" && val !== "5");
      console.log(sts);
      var date =  new Date();
      console.log(date);
         Createschedule(args,sts,date);
   }
 else{
     console.log(error);
   }
 
 })
    
}

function createcustomFields(args){
  var headers = {
    'Authorization': getToken(args),
   'Content-Type': 'application/json' 
};
var options = { 
   method:"POST",
   url:`${getDomain(args)}/api/v2/admin/ticket_fields`,
  headers: headers,
  json:true,
  body:{
      "label_for_customers":"Primary Ticket ID",
      "displayed_to_customers":false,
      "label":"Primary Ticket ID",
      "type":"custom_number"
    }
}; 
// console.log(options);
request(options,(error, res, body) => {

  if(body)
   {        
    // var datas = JSON.parse(body);
     console.log(body);
     //var conver = da.conversations;
   }
 else{
     console.log(error);
   }
 
 })
    
}
function createcustomFields_1(args){
  var headers = {
    'Authorization': getToken(args),
   'Content-Type': 'application/json' 
};
var options = { 
   method:"POST",
   url:`${getDomain(args)}/api/v2/admin/ticket_fields`,
  headers: headers,
  json:true,
  body:{
      "label_for_customers":"Child Ticket ID",
      "displayed_to_customers":false,
      "label":"Child Ticket ID",
      "type":"custom_paragraph"
    }
}; 
// console.log(options);
request(options,(error, res, body) => {

  if(body)
   {        
    // var datas = JSON.parse(body);
     console.log(body);
     //var conver = da.conversations;
   }
 else{
     console.log(error);
   }
 
 })
    
}
function  Createschedule(args,sts,date) {

   $schedule
     .create({
       name: "schedule_fetchdata",
       data: {mins:1,
                status:sts},
       schedule_at: date,
       repeat: {
        time_unit: "minutes",
        frequency:1
      }
     })
     .then(
       function (data) {
         console.log(data);
         console.log("Createschedule 1 MINIT after then fun...  ");
       },
       function (err) {
         console.log(err);
       }
     );
 }


 var contacts = [];
 var r;
 function filterTickets(args,searchdate, i) {
   var status = args['data']['status'];
   status = ((status.map(i => 'status:' + i +'%20OR%20')).join("")).slice(0, -8);
  return new Promise(function (resolve) {              
    let  url= `${getDomain(args)}/api/v2/search/tickets?query="created_at:%27${searchdate}%27%20AND%20(${status})"&page=${i}`;
      var options = {
        headers: {
          "Authorization": `${getToken(args)}`,
          'content-Type': 'application/json'
        }
      };
      
    console.log("OPtion"); console.log(url);
      $request.get(url,options).then(function(data) {
      if (data.status == 200 || data.status == 201) {
        let res=data.response;
          // console.log("status true",JSON.parse(res).results);//resolve(contacts);
        r=JSON.parse(res);
        if (r && r.results.length != 0){
          contacts = contacts.concat(r.results);
           i = i + 1;
           resolve(filterTickets(args,searchdate, i));
        }else {
          contacts = contacts.filter(e => (e.custom_fields.primary_ticket_id == null));
          resolve(contacts);
        }
      }else{
        console.log("False block");
          resolve(filterTickets(args,searchdate, i));
      }
      })
    })
 }

function fetch_agent_api(args) {

  return new Promise(function (resolve, reject) {
    var options = {
      method: "GET",
      url: `${getDomain(args)}/api/v2/agents/me`,
      headers: {
        "Authorization": getToken(args),
        'content-Type': 'application/json'
      }
    };
    request(options, async (err, res, body) => {
      if (body != '') {
        resolve(JSON.parse(body).id);
      }
      else {
        reject(err);
      }
    })
  })

}

function close_child(args, parentid, data1, responder_id) {
  unirest
    .put(`${getDomain(args)}/api/v2/tickets/${data1.id}`)
    .headers({
      "Authorization": getToken(args),
      'content-Type': 'application/json'
    })
    .send({
      "tags": ["Secondary Ticket"],
      "status": 5,
      "responder_id": responder_id,
      "custom_fields": {
         "cf_primary_ticket_id": parentid
      }
    })
    .then((response) => {
      if (response.body) {
        console.log("Child ticket closed");
        
      }
      else {
        console.log("Closing Child error");
      }
      
    })
}

function getParentticket(args, parentid){
  var headers = {
    'Authorization': getToken(args),
   'Content-Type': 'application/json' 
};
var options = { 
   method:"GET",
   url:`${getDomain(args)}/api/v2/tickets/${parentid}`,
  headers: headers
 
};
request(options,(error, res, body) => {

  if(body)
   {        
     var datas = JSON.parse(body);
     if(datas.tags.length != 0){
      var  P_tag = ([...new Set(datas.tags)]).sort();
      update_child(args, parentid,P_tag);
      }else{
          var  P_tag = ["Primary Ticket"];   
          P_tag = ([...new Set(P_tag)]).sort();
         update_child(args, parentid,P_tag);
      }
      console.log("P_c_Ticket_id.......",P_tag);
      
   }
 else{
     console.log(error);
   }
 
 })
    
}

function update_child(args, parentid ,P_tag) {
 
 return new Promise(function (resolve, reject) {
  let conversation = {
    "tags": P_tag
  };
  var options1 = {
    method: "PUT",
    url: `${getDomain(args)}/api/v2/tickets/${parentid}`,
    headers: {
      "Authorization": getToken(args),
      'content-Type': 'application/json'
    },
    json:true,
    body:conversation
  };
  request(options1, function (err, resp, body) {
    if (body) {       
      resolve(true);
      console.log("update tag Child ticket id ");
    }
    else {
      console.log(err);
      console.log('Error!');
      reject(err);
    }
  });
}) 
  
}

function childNoteAdd(args, parentid, data1){
  unirest
    .post(`${getDomain(args)}/api/v2/tickets/${data1.id}/notes`)
    .headers({
      "Authorization": getToken(args),
      'content-Type': 'application/json'
    })
    .send({
     "body": `This ticket is merged with ${parentid}`,
     "private":true
  
    })
    .then((response) => {
      if (response.body) {
        // console.log(response.body);
        console.log("Child ticket note added");
      }
      else {
        console.log("note not add Child error");
      }
      
    })
}
function fetchData(args, t_id) {
  console.log("New Ticket ID", t_id);
  let  url= `${getDomain(args)}/api/v2/tickets/${t_id}`;
  return new Promise(function (resolve) {
    var options = {
      headers: {
        "Authorization": getToken(args),
        'content-Type': 'application/json'
      }
    };
     $request.get(url,options).then(function(data) {
        
   console.log("recentTicketApiStatusCode", data.status);
	  if (data.status == 200 || data.status == 201) {
		let res=data.response;
        resolve(JSON.parse(res));      
	  }else{
		  console.log("False block");
		  resolve(fetchData(args, t_id));
	  }
    })
  })
}

function getParentticket1(args, parentid, data1){
 
  return new Promise(function (resolve) {
  var headers = {
    'Authorization': getToken(args),
   'Content-Type': 'application/json' 
};
var options = { 
   method:"GET",
   url:`${getDomain(args)}/api/v2/tickets/${parentid}`,
  headers: headers
 
};
request(options,(error, res, body) => {

  if(body)
   {        
     var datas = JSON.parse(body);
     resolve(datas); 
   }
 else{
  resolve(getParentticket1(args, parentid, data1));
   }
 
 })
})
}

function update_child1(args, parentid ,p_c_id) {

      if(p_c_id.length == 3){
        var prior = 2;
      }else if(p_c_id.length > 3){
        var prior = 3;
      }else{
        var prior = 1;
      } 
        console.log("prior", prior);

 return new Promise(function (resolve, reject) {       
  let conversation = {
     "priority":prior,
    "custom_fields": {
      "cf_child_ticket_id":p_c_id.join()
    }
  };
  var options1 = {
    method: "PUT",
    url: `${getDomain(args)}/api/v2/tickets/${parentid}`,
    headers: {
      "Authorization": getToken(args),
      'content-Type': 'application/json'
    },
    json:true,
    body:conversation
  };
  request(options1, function (err, resp, body) {
    if (body) {       
      resolve(true);
      console.log("successfully update Child ticket id ");
    }
    else {
      console.log(err);
      console.log('Error!');
      reject(err);
    }
  });
}) 
  
}


function recentTicketsNew12(args, i) {
  return new Promise(function (resolve) {
    let  url= `${getDomain(args)}/api/v2/tickets?order_by=created_at&page=${i}`;
  
      var options = {         
        headers: {
          "Authorization": getToken(args),
          'content-Type': 'application/json'
        }
      };
      console.log("OPtion"); console.log(url,options);
    $request.get(url,options).then(function(data) {
       // console.log("recentTicketData", data);
        console.log("recentTicketApiStatusCode", data.status);
      if (data.status == 200 || data.status == 201) {
      let res=data.response;
      console.log("status true");
      //resolve(JSON.parse(res));
      //resolve(true);
       let recentTickets = JSON.parse(res);
  
          if (i <=4) {
            i = i + 1;
            r_ids_new = r_ids_new.concat(recentTickets);
            resolve(recentTicketsNew12(args, i));
          } else {
            r_ids_new = r_ids_new.filter(e => (e.status == 2 && e.custom_fields.cf_primary_ticket_id == null));
            resolve(r_ids_new);
          }
  
      }else{
        console.log("False block");
          resolve(recentTicketsNew12(args, i));
      }
      })
    })
}

function fetch_conversation(args, id) {
  return new Promise(function (resolve, reject) {
    var options = {
      method: "GET",
      url: `${getDomain(args)}/api/v2/tickets/${id}?include=conversations`,
      headers: {
        "Authorization": getToken(args),
        'content-Type': 'application/json'
      }
    };
    request(options, async (err, res, body) => {
      if (body != '') {
        resolve(JSON.parse(body).conversations);
      }
      else {
        reject(err);
      }
    })
  })
}

async function add_conversation(args, parentid, desc, attachments) {
  // console.log("parent id is/");
  // console.log(parentid);
  return new Promise(function (resolve, reject) {
    let conversation = {
      "body": desc +". "+attachments,
      "private": true
    }
    var options1 = {
      method: "POST",
      url: `${getDomain(args)}/api/v2/tickets/${parentid}/notes`,
      headers: {
        "Authorization": getToken(args),
        'content-Type': 'application/json'
      },
      json:true,
      body:conversation
    };
    request(options1, function (err, resp, body) {
      if (body) {       
        resolve(true);
        console.log('success');
      }
      else {
        console.log(err);
        console.log('Error!');
        reject(err);
      }
    });

    // var form = req.form();
    // //add form field value
    // for (var key in conversation) {
    //   if (conversation.hasOwnProperty(key)) {
    //     // form.append(key, conversation[key]);
    //     let p_value = conversation[key];

    //     if (typeof p_value == 'string') {
    //       form.append(key, conversation[key]);
    //     } else {
    //       form.append(key, JSON.stringify(conversation[key]));
    //     }
    //   }
    // }

    // //add attchments
    // for (var i = 0; i < attchs.length; i++) {

    //   form.append('attachments[]', request.get(attchs[i].attachment_url), { filename: attchs[i].name, contentType: attchs[i].content_type })
    // }
  })
}
function fetch_agent_api(args) {

  return new Promise(function (resolve, reject) {
    var options = {
      method: "GET",
      url: `${getDomain(args)}/api/v2/agents/me`,
      headers: {
        "Authorization": getToken(args),
        'content-Type': 'application/json'
      }
    };
    request(options, async (err, res, body) => {
      if (body != '') {
        resolve(JSON.parse(body).id);
      }
      else {
        reject(err);
      }
    })
  })

}
function getToken(args) {
  return  "Basic " + Buffer.from(args['iparams'].api_key + ':x').toString('base64');
}
function getDomain(args) {
  return `https://${args['iparams'].domain}`;
  // return `https://${args['iparams'].domain}.freshdesk.com`;
}